﻿namespace algoritm_5
{
    class Knapsack
    {
        public static int With_Repeat(int[] cost, int[] weight, int capacity)
        {
            int[] max = new int[capacity + 1];

            for (int i = 1; i <= capacity; i++)
            {
                for (int j = 0; j < weight.Length; j++)
                {
                    if (weight[j] <= i)
                    {
                        max[i] = Math.Max(max[i], cost[j] + max[i - weight[j]]);
                    }
                }
            }
            return max[capacity];
        }
        public static int Without_Repeat(int[] cost, int[] weight, int capacity)
        {
            int[,] matrix = new int[weight.Length + 1, capacity + 1];

            for (int i = 1; i <= weight.Length; i++)
            {
                for (int j = 0; j <= capacity; j++)
                {
                    if (weight[i - 1] > j)
                    {
                        matrix[i, j] = matrix[i - 1, j];
                    }
                    else
                    {
                        var pre_value = matrix[i - 1, j];
                        var new_value = cost[i - 1] + matrix[i - 1, j - weight[i - 1]];
                        matrix[i, j] = Math.Max(pre_value, new_value);
                    }
                }
            }
            return matrix[cost.Length, capacity];
        }
    }
    class Program
    {
        public static Random random = new Random();

        static void Main(string[] args)
        {
            int[] cost = { 3, 2, 10, 1};
            int[] weight = { 5, 7, 4, 2};
            Console.WriteLine("Вместимость рюкзака равна 10");
            Console.Write("Цена: ");
            for (int i = 0; i < 4; i++)
            {
                Console.Write(cost[i] + " ");
            }
            Console.WriteLine();
            Console.Write("Вес: ");
            for (int i = 0; i < 4; i++)
            {
                Console.Write(weight[i] + " ");
            }
            Console.WriteLine();
            Console.Write("Стоимость с повторениями: ");
            Console.WriteLine(Knapsack.With_Repeat(cost, weight, 10));
            Console.Write("Стоимость без повторений: ");
            Console.WriteLine(Knapsack.Without_Repeat(cost, weight, 10));
            Console.ReadKey();
        }
    }
}