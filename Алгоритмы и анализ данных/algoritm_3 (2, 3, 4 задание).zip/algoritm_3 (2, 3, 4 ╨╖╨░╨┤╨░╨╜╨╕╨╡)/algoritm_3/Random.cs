﻿namespace algoritm_3
{
    class LinkedListForTask
    {
        public class Node
        {
            private Node next;
            private int count;
            private Node random;

            internal Node() //конструктор без параметров
            {
                count = 0;
                next = null;
            }

            internal Node Next { get { return next; } set { next = value; } }  //свойства
            internal int Count { get { return count; } set { count = value; } }
            internal Node Random { get { return random; } set { random = value; } }
        }

        private Node head; //закрытое поле
        public LinkedListForTask(int length) //конструктор с параметром
        {
            int a = 1;
            head = new Node();
            Node node = head;
            for (int i = 0; i < length; i++)
            {
                if (node.Next == null)
                {
                    Console.Write($"Введите значение элемента №{a}: ");
                    a++;
                    int count = int.Parse(Console.ReadLine());
                    node.Count = count;
                    node.Next = new Node();
                }
                node = node.Next;
            }
        }

        internal Node Head { get { return head; } } //свойство

        public void SetRandom(int length) //метод, устанавливающий поле Random у каждого узла
        {
            Random random = new Random();
            Node node = head;
            while (node != null)
            {
                node.Random = head;
                int k = random.Next(0, length);
                for (int i = 0; i < k - 1; i++)
                {
                    node.Random = node.Random.Next;
                }
                node = node.Next;
            }
        }
    }
}

