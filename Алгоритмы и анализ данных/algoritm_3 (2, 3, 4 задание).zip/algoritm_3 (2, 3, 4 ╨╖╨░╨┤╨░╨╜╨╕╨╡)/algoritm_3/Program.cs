﻿namespace algoritm_3
{
    class Program
    {
        public static void CopyList(LinkedList<int> theList, LinkedList<int> newList) // 2 задание
        {
            LinkedListNode<int> node = theList.First;
            while (node != null)
            {
                newList.AddLast(node.Value);
                node = node.Next;
            }
        }
        public static LinkedList<int> Task_4(LinkedListNode<int> node, int x) //4 задание
        {
            LinkedList<int> buffer = new LinkedList<int>();
            buffer.AddFirst(x);
            while (node != null)
            {
                if (node.Value < x) //разделение исходного списка
                {
                    buffer.AddFirst(node.Value);
                }
                else
                {
                    if (node.Value != x)
                    {
                        buffer.AddLast(node.Value);
                    }
                }
                node = node.Next;
            }
            return buffer;
        }
        public static LinkedListForTask.Node Task_6(LinkedListForTask list) //6 задание
        {
            LinkedListForTask.Node node = list.Head;

            while (node != null) //создание дубликатов node,
            {                    //содержащих ссылки на random 
                LinkedListForTask.Node copyofnode = new LinkedListForTask.Node();
                copyofnode.Count = node.Count;
                copyofnode.Next = node.Random;
                node.Random = copyofnode;
                node = node.Next;
            }

            node = list.Head;
            LinkedListForTask.Node result = list.Head.Random;
            while (node != null) //связываем копии ссылками на random 
            {
                LinkedListForTask.Node copyofnode = node.Random;
                copyofnode.Random = copyofnode.Next.Random;
                node = node.Next;
            }

            node = list.Head;
            while (node != null) //разъединяем списки
            {
                LinkedListForTask.Node copyofnode = node.Random;
                node.Random = copyofnode.Next;
                if (node.Next != null)
                    if (node.Next.Random != null)
                        copyofnode.Next = node.Next.Random;
                node = node.Next;
            }

            return result;
        }
        public static void Input(LinkedList<int> list) // вывод списка
        {
            foreach (int elem in list)
            {
                Console.Write(elem + " ");
            }
            Console.WriteLine();
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Задание №2");
            int[] my_list = {4, 8, 1, 6, 5, 3};
            Console.Write("Исходный список: ");
            LinkedList<int> firstList = new LinkedList<int>(my_list);
            Input(firstList);
            Console.WriteLine();
            Console.WriteLine("Задание №4");
            Console.Write("Введите значение, вокруг коротого будет разбиение: ");
            int a;
            a = int.Parse(Console.ReadLine());
            firstList = Task_4(firstList.First, a);
            Input(firstList);
            Console.WriteLine("Список скопированный: ");
            LinkedList<int> secondList = new LinkedList<int>();
            CopyList(firstList, secondList);
            Input(secondList);
            Console.WriteLine();
            Console.WriteLine("Задание №6");
            Console.Write("Введите длину списка: ");
            int length = int.Parse(Console.ReadLine());
            LinkedListForTask listForTask6 = new LinkedListForTask(5);
            listForTask6.SetRandom(length);
            LinkedListForTask.Node nodeFor6 = listForTask6.Head;
            Console.WriteLine();
            Console.WriteLine("Исходный список:");
            for (int i = 0; i < length; i++)
            {
                Console.WriteLine(nodeFor6.Count + " - " + nodeFor6.Random.Count);
                nodeFor6 = nodeFor6.Next;
            }
            Console.WriteLine();
            LinkedListForTask.Node nodeFrom6 = Task_6(listForTask6);
            Console.WriteLine("Список скопированный:");
            for (int i = 0; i < length; i++)
            {
                Console.WriteLine(nodeFrom6.Count + " - " + nodeFrom6.Random.Count);
                nodeFrom6 = nodeFrom6.Next;
            }
            Console.ReadLine();
        }
    }
}
