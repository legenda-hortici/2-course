import time
import random

list_len = random.randint(1000, 10000)
list_ = [random.randint(-100, 100) for i in range(list_len)]


def shaker_sort(list_):
    left = 0
    right = len(list_) - 1
    while left <= right:
        for i in range(left, right, + 1):
            if list_[i] > list_[i + 1]:
                list_[i], list_[i + 1] = list_[i + 1], list_[i]
        right -= 1
        for i in range(right, left, -1):
            if list_[i - 1] > list_[i]:
                list_[i], list_[i - 1] = list_[i - 1], list_[i]
        left += 1


def mergeSort(list_):
    if len(list_) == 1:
        return list_
    middle = (len(list_) - 1) // 2
    list_1 = mergeSort(list_[:middle + 1])
    list_2 = mergeSort(list_[middle + 1:])
    result = merge(list_1, list_2)
    return result


def merge(list_1, list_2):
    list = []
    i = 0
    j = 0
    while (i <= len(list_1) - 1 and j <= len(list_2) - 1):
        if list_1[i] < list_2[j]:
            list.append(list_1[i])
            i += 1
        else:
            list.append(list_2[j])
            j += 1
    if i > len(list_1) - 1:
        while (j <= len(list_2) - 1):
            list.append(list_2[j])
            j += 1
    else:
        while (i <= len(list_1) - 1):
            list.append(list_1[i])
            i += 1
    return list


total_time = 0
for i in range(5):
    start = time.time()
    qsorted_list = shaker_sort(list_)
    end = time.time()
    total = end - start
    total_time += total
result = total_time / 5
print(f'Среднее время шейкерной сортировки: {result}')

total_time = 0
for i in range(5):
    start = time.time()
    qsorted_list = mergeSort(list_)
    end = time.time()
    total = end - start
    total_time += total
result = total_time / 5
print(f'Среднее время cортировки слиянием: {result}')
