import time

def fibonacci_rec(n):
    if n <= 1:
        return 1
    else:
        return fibonacci_rec(n - 1) + fibonacci_rec(n - 2)

def fibonacci_iter(n):
    a = 0
    b = 1
    for _ in range(n):
        a, b = b, a + b
    return a

element = int(input('Количество чисел последовательности: '))
print(element, 'элемент последовательности равен', fibonacci_rec(element - 1), 'при помощи рекурсивного метода')
print(element, 'элемент последовательности равен', fibonacci_iter(element), 'при помощи итерационного метода')

start = time.time()
rec = fibonacci_rec(element)
end = time.time()
total = end - start
print(f'Время работы рекурсивного метода: {total}')

start = time.time()
iter = fibonacci_iter(element)
end = time.time()
total = end - start
print(f'Время работы итерационного метода: {total}')




